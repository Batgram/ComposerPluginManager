<?php

require_once __DIR__ . "/src/bootstrap.php";

use Composer\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\BufferedOutput;

$application = new Application();

$input = new ArrayInput([
    'command' => 'update',
]);

$output = new BufferedOutput();

$application->run($input, $output);

return $output->fetch();