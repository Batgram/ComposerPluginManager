<?php declare(strict_types=1);











namespace Composer\Plugin;

use UnexpectedValueException;

class PluginBlockedException extends UnexpectedValueException
{
}
