<?php declare(strict_types=1);











namespace Composer\Plugin\Capability;







interface Capability
{
}
