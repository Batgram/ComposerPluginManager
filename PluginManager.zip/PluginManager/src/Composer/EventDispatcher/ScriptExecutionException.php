<?php declare(strict_types=1);











namespace Composer\EventDispatcher;






class ScriptExecutionException extends \RuntimeException
{
}
